import pyodbc, json, requests 
#import MySQLdb.cursors
import re
from flask import Flask, render_template, request, jsonify, make_response, redirect, url_for, session, flash
from flask_wtf import FlaskForm, form
#from flask_mysqldb import MySQL
#from werkzeug import generate_password_hash

# pip3.9 install WTForms
from wtforms import StringField, IntegerField, PasswordField, SubmitField
from wtforms.validators import DataRequired, EqualTo, Email

import json

app = Flask(__name__)
app.config['SECRET_KEY'] = 'mysecretkey'


# DB Connection - Uncomment and fill in the details
server = 'instagramwebapp.database.windows.net'
database = 'instagramapp'
username = 'megmck'
password = 'Forrestgump@100'
driver= '{ODBC Driver 13 for SQL Server}'

cnxn = pyodbc.connect('DRIVER='+driver+';PORT=1433;SERVER='+server+';PORT=1443;DATABASE='+database+';UID='+username+';PWD='+ password)
cursor = cnxn.cursor()

#Global Variables
movies = []
newMovies = []
allGenres = []
reviewingForm = []

#Username = []
#Password = []

#URLS
RAAA = "https://instagramappapi.azurewebsites.net/api/RAAA/triggers/manual/invoke/rest/v1/allmovies?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=7oaWWbH15CrOUqgSPzQ8uPNrN2IIR1IxwoggCXRlx6M"
UPM = "https://instagramappapi.azurewebsites.net:443/api/UPM/triggers/manual/invoke?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=p5Aj3IHIhRcNk3hBafTHdOpg2tiO4ysyKuq_nK7m8CI"
RNEW = "https://instagramappapi.azurewebsites.net/api/RNEW/triggers/manual/invoke/rest/v1/newmovies?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=w717BBpyc-1x1qLMqtWw5KIycJ3dk1YtJEH1ZkMDrV8"
#DIA = "https://instagramappapi.azurewebsites.net/api/DIA/triggers/manual/invoke/{ID}?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=ZGaANvbrViEIYIlFZ3ZiqkPKEaOd7-E94r6mhgMW80w"
GAG = "https://instagramappapi.azurewebsites.net/api/GAG/triggers/manual/invoke/rest/v1/allgenres?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=F-w_IrLeB45fLk5QtlCCqnzIYiklELQAO6wfjfd31hI"
CAU = "https://instagramappapi.azurewebsites.net/api/CAU/triggers/manual/invoke/rest/v1/createuser?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=eikKZSbXCidSG0c1jVmsCQNfpgEivgJJGJOQxy5MJLE"
#CAM = "https://instagramappapi.azurewebsites.net/api/CAM/triggers/manual/invoke/rest/v1/createvideo?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=1N9iFyZquNdauNkmHB6tLD3IPREpg_aDCAh4lIjE2M0"
CAMM = "https://instagramappapi.azurewebsites.net/api/CAMM/triggers/manual/invoke/rest/v1/uploadavideo?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=0zJtWuaCKl5imch-sklJfvr2w0Ebzu2aGjq25AoOPvQ"
#CAR = "https://instagramappapi.azurewebsites.net/api/CAR/triggers/manual/invoke/rest/v1/createreview?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=zDpaARD0jcsn2SnQr7-oPQxGQYnM_EOF_XrVn9DmGzM"
RAR = "https://instagramappapi.azurewebsites.net/api/RAR/triggers/manual/invoke/rest/v1/getreviews?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=5ZH9OLz2kkHHdRvJ_pquW0X5hugHXL7eUk_OJZ9vBro"
# Forms
class LoginForm(FlaskForm):
    email = StringField('email', validators=[DataRequired(), Email()])
    password = PasswordField('password', validators=[DataRequired()])
    submit = SubmitField('Sign in')

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    forename = StringField('Forename', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    confirm_password = PasswordField('Confirm Password',validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField('Sign up')

class MovieForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    director = StringField('Director', validators=[DataRequired()])
    publisher = StringField('Publisher', validators=[DataRequired()])
    producer = StringField('Producer', validators=[DataRequired()])
    runtime = IntegerField('Runtime', validators=[DataRequired()])
    genre = StringField('Genre',validators=[DataRequired()])
    rating = StringField('Rating', validators=[DataRequired()])
    blobname = StringField('BlobName', validators=[DataRequired()])
    submit = SubmitField('Upload Movie')

class reviewForm(FlaskForm):
    reviewtext = StringField('ReviewText', validators=[DataRequired()])
    stars = IntegerField('Stars', validators=[DataRequired()])
    movieID = IntegerField('MovieID', validators=[DataRequired()])

# Endpoints go here


#Login 
@app.route("/login", methods=['GET', 'POST'])
def login():
    loginform = LoginForm()
    
    print('Inside login endpoint')

    if loginform.validate_on_submit():

        cursor.execute("SELECT * FROM Users WHERE email = ?", loginform.email.data)
        user = cursor.fetchone()

        print(user)

        userPass = user[5] # 5 is the index of the password
        
        if user and loginform.password.data == userPass:
            flash('User logged in', 'success')


            global signed_in_id, signed_in_username, signed_in_email, signed_in_forename, signed_in_surname, is_signed_in

            # Indexs may be incorrect, check the printed out object and make sure the order is correct
            signed_in_id = user[0]
            signed_in_username = user[1]
            signed_in_forename = user[2]
            signed_in_surname = user[3]
            signed_in_email = user[4]
            is_signed_in = True # Used to know if the user is signed in, gets set to true and false whne logged out. Can be passed to any page and checked to know what to display on that page. I.E Display login or account page

            return redirect(url_for('home'))
        else:
            flash('Login Unsuccessful.', 'danger')

    return render_template('login.html', loginform = loginform)

#Logout
@app.route("/logout")
def logout():
    global is_signed_in 
    is_signed_in = False
    flash('Logged out succesfully.', 'success')
    return redirect(url_for('home'))


#allmovies
@app.route("/")
@app.route("/home")
def home():
    movies.clear()
    response = requests.get(RAAA)

    if response.text != "":
        Data : dict = response.json()

        for i in Data:
            movies.append(i)
    else:
        Data : dict = {}
    
    print(movies)

    return render_template('home.html', movieshtml=movies)

#new releases
@app.route("/NewReleases")
def NewReleases():
    newMovies.clear()
    response = requests.get(RNEW)

    if response.text != "":
        Data : dict = response.json()

        for i in Data:
            newMovies.append(i)
    else:
        Data : dict = {}
    
    return render_template('NewReleases.html', newmovieshtml = newMovies)
    #newmovies = newmovies(RNEW)
    #print(newmovies)


#/videos/et.mp4


#genre 
@app.route("/Genre")
def Genre():
    allGenres.clear()
    response = requests.get(GAG)

    if response.text != "":
        Data : dict = response.json()

        for i in Data:
            allGenres.append(i)
    else:
        Data : dict = {}
    return render_template('Genre.html', getallgenres = allGenres)

#Register
@app.route("/register", methods=['GET', 'POST'])
def register():
    registerForm = RegistrationForm()

    if registerForm.validate_on_submit():

        registerData = {
            "username" : registerForm.username.data,
            "forename" : registerForm.forename.data,
            "surname" : registerForm.surname.data,
            "email" : registerForm.email.data,
            "password" : registerForm.password.data
        }

        headers = {
            'Content-Type': 'application/json'
        }

        postUser = requests.post(CAU, headers=headers, data=json.dumps(registerData) )

        if postUser.status_code == 201:
            flash(f'Account created', 'success')
            return redirect(url_for('login'))
        else:
            flash('Registration Unsuccessful.', 'danger')
            
    return render_template('register.html', registerForm = registerForm)

#leave a review
#@app.route("/Review")
#def Review():
#    return render_template('Review.html')


@app.route("/Review", methods=['GET', 'POST'])
def review():
    reviewForm = reviewingForm()

    if reviewForm.validate_on_submit():

        reviewData = {
            "reviewtext" : reviewForm.reviewtext.data,
            "stars" : reviewForm.stars.data,
            "movieID" : reviewForm.movieID.data
        }

        headers = {
            'Content-Type': 'application/json'
        }

        postreview = requests.post(RAR, headers=headers, data=json.dumps(reviewData) )

        if postreview.status_code == 201:
            flash(f'Review added', 'success')
            return redirect(url_for('login'))
        else:
            flash('Review Unsuccessful.', 'danger')
            
    return render_template('Review.html', reviewForm = reviewForm)



#my account
#@app.route("/Account")
#def Account():
#    return render_template('Account.html')

#my account
#@app.route("/AddMovie")
#def AddMovie():
#    return render_template('AddMovie.html')

#add a movie
@app.route("/AddMovie", methods=['GET', 'POST'])
def AddMovie():
    movieForm = MovieForm()

    if movieForm.validate_on_submit():

        movieData = {
            "title" : movieForm.title.data,
            "director" : movieForm.director.data,
            "publisher" : movieForm.publisher.data,
            "producer" : movieForm.producer.data,
            "runtime" : movieForm.runtime.data,
            "genre" : movieForm.genre.data,
            "rating" : movieForm.rating.data,
            "blobname" : movieForm.blobname.data,
        }

        headers = {
            'Content-Type': 'application/json'
        }

        postMovie = requests.post(CAMM, headers=headers, data=json.dumps(movieData) )

        if postMovie.status_code == 201:
            flash(f'Movie uploaded', 'success')
            return redirect(url_for('login'))
        else:
            flash('Movie failed to upload, please try again.', 'danger')
            
    return render_template('AddMovie.html', movieForm = movieForm)



#Functions




# Run Flask server
if __name__ == "__main__":
    app.run(debug=True)