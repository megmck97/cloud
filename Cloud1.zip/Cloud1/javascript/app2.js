RAV = "https://instagramappapi.azurewebsites.net:443/api/RAV/triggers/manual/invoke?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=mGCW_2x9d8YgQPP4k9tCi9CJPmVn1TzU0g-ivjqlv3E";
UPM = "https://instagramappapi.azurewebsites.net:443/api/UPM/triggers/manual/invoke?api-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=p5Aj3IHIhRcNk3hBafTHdOpg2tiO4ysyKuq_nK7m8CI";

BLOB_ACCOUNT = "https://storageaccountinstabbca.blob.core.windows.net/videos";


//Handlers for button clicks
$(document).ready(function() {

 
  $("#retVideos").click(function(){

      //Run the get asset list function
      getVideos();

  }); 

   //Handler for the new asset submission button
  $("#subNewForm").click(function(){

    //Execute the submit new asset function
    submitNewAsset();
    
  }); 
});

//A function to submit a new asset to the REST endpoint 
function submitNewAsset(){
  var subObj = {
    AssetLabel: $('#AssetLabel').val(),
    Cost: $('#Cost').val(),
    AssetType: $('#AddLine1').val()
  }

  subObj = JSON.stringify(subObj);

  $post({
    url: UPM,
    data: subObj,
    contentType: 'application/json; charset=utf-8'
  }).done(function (response) {
    getVideos();
  });
 
  //Create a form data object
  submitData = new FormData();

  //Get form variable and append them to the form data object
  submitData.append('fileName', $('#fileName').val());
  submitData.append('userID', $('#userID').val());
  submitData.append('userName', $('#userName').val());
  submitData.append('file', $("#UpFile")[0].files[0]);

  //Post the form data top the endpoint, note the need to set the content type header
  $.ajax({
    url:UPM, 
    data: submitData,
    Cache: false,
    enctype: 'multipart/form-data',
    contentType:false,
    processData:false,
    type:'POST',
    success:function(data){

    }
  });
}

//A function to get a list of all the assets and write them to the Div with the AssetList Div
function getVideos(){
  $('#VideoList').html('<div class="spinner-border" role="status"><span class="sr-only">&nbsp;</span>');
  $.getJSON(RAV, function(data){

    //create an array to hold all the retrieved assets
    var items = [];

    $.each(data, function(key, val){
      items.push("</hr>");
      items.push("<img src='"+ BLOB_ACCOUNT + val["filePath"] + "'width='400'/> <br/>")
      items.push("File : " + val["fileName"] + "<br/>");
      items.push("Uploaded by: " + val["userName"] + "(user id:" + val["userID"]+") <br/>");
      items.push("<hr/>");
    });

    $('#VideoList').empty();

    $("<ul/>", {
      "class":"my-new-list",
      html:items.join("")
    }).appendTo("#VideoList");
  }); 
}