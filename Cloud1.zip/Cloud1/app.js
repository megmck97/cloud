//The URIs of the REST endpoint
IUPS = "";
RAA = "/api/RAA/triggers/manual/invoke/rest/v1/allpostsapi-version=2020-05-01-preview&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=7a-OcxBKjRw08TJLU2TK_K3AhLxjxKqoOjzrLdI3xrw";

BLOB_ACCOUNT = "";

//Handlers for button clicks
$(document).ready(function() {

 
  $("#retImages").click(function(){

      //Run the get asset list function
      getImages();

  }); 

   //Handler for the new asset submission button
  $("#subNewForm").click(function(){

    //Execute the submit new asset function
    submitNewAsset();
    
  }); 
});

//A function to submit a new asset to the REST endpoint 
function submitNewAsset(){
  
 

}

//A function to get a list of all the assets and write them to the Div with the AssetList Div
function getImages(){

 
}

function getAssetList(){
    $getJSON(RAA, function(data) {
        var items = [];
    })
}


// Inerted code
//The URIs of the REST endpoint
IUPS = "https://prod-09.eastus.logic.azure.com:443/workflows/441e024fbe5f42e5b93df35276232a1f/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=qOOG42p_UDfSo5WuIV11EQ8-FEIfrYxL9JORu8mJCZg";
RAI = "https://prod-18.northcentralus.logic.azure.com:443/workflows/3fd91f7076354cf79102604ea513f7ca/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=8HqRVbyHH4PKBKWpfsNnQ_V9lQRdhh_gSoOBAWUpLJ8";

BLOB_ACCOUNT = "https://storageaccountinstabbca.blob.core.windows.net/videos";


//Handlers for button clicks
$(document).ready(function() {

 
  $("#retImages").click(function(){

      //Run the get asset list function
      getImages();

  }); 

   //Handler for the new asset submission button
  $("#subNewForm").click(function(){

    //Execute the submit new asset function
    submitNewAsset();
    
  }); 
});

//A function to submit a new asset to the REST endpoint 
function submitNewAsset(){
 
  //Create a form data object
  submitData = new FormData();

  //Get form variable and append them to the form data object
  submitData.append('fileName', $('#fileName').val());
  submitData.append('userID', $('#userID').val());
  submitData.append('userName', $('#userName').val());
  submitData.append('file', $("#UpFile")[0].files[0]);

  //Post the form data top the endpoint, note the need to set the content type header
  $.ajax({
    url:IUPS, 
    data: submitData,
    Cache: false,
    enctype: 'multipart/form-data',
    contentType:false,
    processData:false,
    type:'POST',
    success:function(data){

    }
  });
}

//A function to get a list of all the assets and write them to the Div with the AssetList Div
function getImages(){
  $('#ImageList').html('<div class="spinner-border" role="status"><span class="sr-only">&nbsp;</span>');
  $.getJSON(RAI, function(data){

    //create an array to hold all the retrieved assets
    var items = [];

    $.each(data, function(key, val){
      items.push("</hr>");
      items.push("<img src='"+ BLOB_ACCOUNT + val["filePath"] + "'width='400'/> <br/>")
      items.push("File : " + val["fileName"] + "<br/>");
      items.push("Uploaded by: " + val["userName"] + "(user id:" + val["userID"]+") <br/>");
      items.push("<hr/>");
    });

    $('#ImageList').empty();

    $("<ul/>", {
      "class":"my-new-list",
      html:items.join("")
    }).appendTo("#ImageList");
  }); 
}